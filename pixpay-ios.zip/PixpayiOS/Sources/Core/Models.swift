import Foundation

struct User: Decodable, Equatable {
    var id: String?
    var name: String?
    var phone: String?
    var frozen: Bool?
}

struct TxMeta: Codable, Hashable {
    var t: String?
    var bk: String?
    var no: String?
    var nm: String?
}

struct Tx: Decodable, Identifiable, Hashable {
    let id: String
    var ref: String?
    var ty: String?
    var ti: String?
    var a: Double?
    var c: String?
    var note: String?
    var fee: Double?
    var fee_admin: Double?
    var fee_pajak: Double?
    var total: Double?
    var st: String?
    var ts: Double?
    var m: TxMeta?
    var va: String?
    var qr: String?

    var amount: Double { a ?? 0 }
    var status: String { st ?? "" }
    var date: Date { Date(timeIntervalSince1970: (ts ?? 0) / 1000) }
}

struct Noti: Decodable, Identifiable {
    var ts: Double?
    var t: String?
    var b: String?
    var r: Int?
    var id: String { "\(ts ?? 0)-\(t ?? "")" }
}

struct Cfg: Decodable {
    var fee = 2500.0
    var fd = 1000.0
    var feeTarik = 2000.0
    var feeTarikKecil = 1000.0
    var pajakPct = 11.0
    var feeIsi = 1000.0
    var vaAktif = 0
    var mt = 0
    var an = ""
    var small = 100000.0
    var wa = ""
    var tg = ""
    var em = ""
    var jam = ""
    var qrisOut = false

    init() {}

    private enum CodingKeys: String, CodingKey {
        case fee, fd, mt, an, small, wa, tg, em, jam
        case feeTarik = "fee_tarik"
        case feeTarikKecil = "fee_tarik_kecil"
        case pajakPct = "pajak_pct"
        case feeIsi = "fee_isi"
        case vaAktif = "va_aktif"
        case qrisOut = "qris_out"
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        fee = try c.decodeIfPresent(Double.self, forKey: .fee) ?? 2500
        fd = try c.decodeIfPresent(Double.self, forKey: .fd) ?? 1000
        feeTarik = try c.decodeIfPresent(Double.self, forKey: .feeTarik) ?? 2000
        feeTarikKecil = try c.decodeIfPresent(Double.self, forKey: .feeTarikKecil) ?? 1000
        pajakPct = try c.decodeIfPresent(Double.self, forKey: .pajakPct) ?? 11
        feeIsi = try c.decodeIfPresent(Double.self, forKey: .feeIsi) ?? 1000
        vaAktif = try c.decodeIfPresent(Int.self, forKey: .vaAktif) ?? 0
        mt = try c.decodeIfPresent(Int.self, forKey: .mt) ?? 0
        an = try c.decodeIfPresent(String.self, forKey: .an) ?? ""
        small = try c.decodeIfPresent(Double.self, forKey: .small) ?? 100000
        wa = try c.decodeIfPresent(String.self, forKey: .wa) ?? ""
        tg = try c.decodeIfPresent(String.self, forKey: .tg) ?? ""
        em = try c.decodeIfPresent(String.self, forKey: .em) ?? ""
        jam = try c.decodeIfPresent(String.self, forKey: .jam) ?? ""
        qrisOut = try c.decodeIfPresent(Bool.self, forKey: .qrisOut) ?? false
    }
}

struct MeResp: Decodable {
    var user: User?
    var balance: Double?
    var unread: Int?
    var nt: [Noti]?
    var cfg: Cfg?
}

struct AuthResp: Decodable {
    var token: String?
    var user: User?
    var admin: Int?
}

struct ProfileResp: Decodable {
    var user: User?
}

struct OkResp: Decodable {
    var ok: Int?
}

struct ChatMsg: Decodable, Identifiable {
    private let serverId: String?
    var from: String?
    var text: String?
    var ts: Double?
    var cid: String?

    private enum CodingKeys: String, CodingKey {
        case serverId = "id"
        case from, text, ts, cid
    }

    var id: String { serverId ?? "\(ts ?? 0)|\(from ?? "")|\(text ?? "")" }
}

struct Ticket: Decodable, Identifiable {
    private let serverId: String?
    var c: String?
    var tid: String?
    var m: String?
    var ts: Double?
    var st: String?
    var r: String?

    private enum CodingKeys: String, CodingKey {
        case serverId = "id"
        case c, tid, m, ts, st, r
    }

    var id: String { serverId ?? "\(ts ?? 0)|\(m ?? "")" }
}
