import Foundation

enum APIError: LocalizedError {
    case network
    case unauthorized
    case server(String)

    var errorDescription: String? {
        switch self {
        case .network: return "Tidak bisa terhubung ke server. Periksa koneksi internet."
        case .unauthorized: return "Sesi kamu sudah berakhir. Silakan masuk lagi."
        case .server(let message): return message
        }
    }
}

final class APIClient {
    var token: String?

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        return URLSession(configuration: config)
    }()

    func get<T: Decodable>(_ path: String) async throws -> T {
        try await send(method: "GET", path: path, body: nil)
    }

    func post<T: Decodable>(_ path: String, _ body: [String: Any] = [:]) async throws -> T {
        try await send(method: "POST", path: path, body: body)
    }

    private func send<T: Decodable>(method: String, path: String, body: [String: Any]?) async throws -> T {
        guard let url = URL(string: AppConfig.apiBase + "/api" + path) else {
            throw APIError.server("Alamat server tidak valid")
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let token {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }

        let result: (Data, URLResponse)
        do {
            result = try await session.data(for: request)
        } catch {
            throw APIError.network
        }
        let (data, response) = result
        guard let http = response as? HTTPURLResponse else { throw APIError.network }
        if http.statusCode == 401 { throw APIError.unauthorized }
        guard (200...299).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode(ErrorBody.self, from: data))?.error
            throw APIError.server(message ?? "Terjadi gangguan (\(http.statusCode))")
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw APIError.server("Respons server tidak sesuai")
        }
    }
}

private struct ErrorBody: Decodable {
    let error: String?
}
