import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var booting = true
    @Published private(set) var loggedIn = false
    @Published private(set) var user = User()
    @Published private(set) var balance = 0.0
    @Published private(set) var unread = 0
    @Published private(set) var cfg = Cfg()
    @Published private(set) var transactions: [Tx] = []
    @Published private(set) var notes: [Noti] = []

    let api = APIClient()
    private let tokenKey = "pixpay.session.token"

    init() {
        api.token = Keychain.load(key: tokenKey)
    }

    func boot() async {
        if api.token != nil {
            loggedIn = true
            await refresh()
        }
        booting = false
    }

    func refresh() async {
        guard api.token != nil else { return }
        do {
            let me: MeResp = try await api.get("/me")
            let txs: [Tx] = try await api.get("/tx")
            user = me.user ?? User()
            balance = me.balance ?? 0
            unread = me.unread ?? 0
            cfg = me.cfg ?? Cfg()
            notes = me.nt ?? []
            transactions = txs
        } catch APIError.unauthorized {
            logout()
        } catch {
            // Gangguan sementara: data terakhir tetap ditampilkan.
        }
    }

    func login(phone: String, pin: String) async throws {
        let response: AuthResp = try await api.post("/login", ["phone": phone, "pin": pin])
        try await startSession(response)
    }

    func register(name: String, phone: String, pin: String) async throws {
        let response: AuthResp = try await api.post("/register", ["name": name, "phone": phone, "pin": pin])
        try await startSession(response)
    }

    private func startSession(_ response: AuthResp) async throws {
        guard let token = response.token, !token.isEmpty, response.admin != 1 else {
            throw APIError.server("Nomor atau PIN tidak sesuai")
        }
        api.token = token
        Keychain.save(token, key: tokenKey)
        loggedIn = true
        await refresh()
    }

    func logout() {
        api.token = nil
        Keychain.delete(key: tokenKey)
        loggedIn = false
        user = User()
        balance = 0
        unread = 0
        transactions = []
        notes = []
    }

    func transfer(type: String, dest: String, bank: String, holder: String,
                  amount: Double, note: String, pin: String) async throws -> Tx {
        let tx: Tx = try await api.post("/transfer", [
            "type": type, "to": dest, "bank": bank, "name": holder,
            "amount": amount, "note": note, "pin": pin
        ])
        await refresh()
        return tx
    }

    func withdraw(amount: Double, bank: String, no: String, holder: String, pin: String) async throws -> Tx {
        let tx: Tx = try await api.post("/withdraw", [
            "amount": amount, "bank": bank, "no": no, "name": holder, "pin": pin
        ])
        await refresh()
        return tx
    }

    func pay(qris: String, amount: Double, note: String, pin: String) async throws -> Tx {
        let tx: Tx = try await api.post("/pay", [
            "qris": qris, "amount": amount, "note": note, "pin": pin
        ])
        await refresh()
        return tx
    }

    func topup(method: String, amount: Double) async throws -> Tx {
        let tx: Tx = try await api.post("/topup", ["method": method, "amount": amount])
        await refresh()
        return tx
    }

    func changePin(old: String, new: String) async throws {
        let _: OkResp = try await api.post("/pin", ["old": old, "new": new])
    }

    func updateProfile(name: String, phone: String) async throws {
        let response: ProfileResp = try await api.post("/profile", ["name": name, "phone": phone])
        if let updated = response.user {
            user = updated
        }
    }

    func markNotesRead() async {
        do {
            let _: OkResp = try await api.post("/notif/read")
            await refresh()
        } catch {
            // Tidak kritis: daftar tetap tampil.
        }
    }

    func fetchChat() async throws -> [ChatMsg] {
        try await api.get("/chat")
    }

    func sendChat(text: String, cid: String) async throws -> ChatMsg {
        try await api.post("/chat", ["text": text, "cid": cid])
    }

    func fetchTickets() async throws -> [Ticket] {
        try await api.get("/tickets")
    }

    func createTicket(category: String, orderId: String, message: String) async throws -> Ticket {
        try await api.post("/ticket", ["cat": category, "tid": orderId, "msg": message])
    }
}
