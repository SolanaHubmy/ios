import AVFoundation
import PhotosUI
import SwiftUI
import UIKit

struct ScanView: View {
    @EnvironmentObject private var store: AppStore
    @State private var payCode: PayCode?
    @State private var message: String?
    @State private var pasteOpen = false
    @State private var pickerItem: PhotosPickerItem?
    @State private var cameraStatus = AVCaptureDevice.authorizationStatus(for: .video)

    var body: some View {
        VStack(spacing: 16) {
            cameraArea
                .frame(maxWidth: 560, minHeight: 300, maxHeight: 340)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            if let message {
                Text(message)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
            }
            HStack(spacing: 12) {
                PhotosPicker(selection: $pickerItem, matching: .images) {
                    Label("Import gambar", systemImage: "photo.on.rectangle")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button {
                    pasteOpen = true
                } label: {
                    Label("Tempel kode", systemImage: "doc.on.clipboard")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }
            .frame(maxWidth: 560)
            Spacer(minLength: 0)
        }
        .padding()
        .navigationTitle("Bayar QRIS")
        .sheet(item: $payCode) { code in
            NavigationStack { PayView(code: code) }
        }
        .sheet(isPresented: $pasteOpen) {
            PasteCodeSheet { raw in
                handle(raw)
            }
        }
        .onChange(of: pickerItem) { item in
            guard let item else { return }
            Task { await importImage(item) }
        }
    }

    @ViewBuilder
    private var cameraArea: some View {
        switch cameraStatus {
        case .authorized:
            ScannerRepresentable { raw in
                handle(raw)
            }
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.white.opacity(0.85), lineWidth: 3)
                    .padding(40)
            )
        case .notDetermined:
            VStack(spacing: 12) {
                Text("Izinkan kamera untuk memindai kode QRIS.")
                    .multilineTextAlignment(.center)
                Button("Izinkan kamera") {
                    AVCaptureDevice.requestAccess(for: .video) { granted in
                        DispatchQueue.main.async {
                            cameraStatus = granted ? .authorized : .denied
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.subtleFill)
        default:
            VStack(spacing: 12) {
                Text("Akses kamera ditolak. Aktifkan di Pengaturan iOS, atau gunakan Import gambar.")
                    .multilineTextAlignment(.center)
                Button("Buka Pengaturan") {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                }
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.subtleFill)
        }
    }

    private func handle(_ raw: String) {
        guard let code = QRIS.parse(raw) else {
            message = "Kode ini bukan QRIS atau PIXPAY"
            return
        }
        if code.kind == .pixpay && code.toPhone == store.user.phone {
            message = "Itu kode PIXPAY kamu sendiri"
            return
        }
        message = nil
        payCode = code
    }

    private func importImage(_ item: PhotosPickerItem) async {
        defer { pickerItem = nil }
        guard let data = try? await item.loadTransferable(type: Data.self),
              let image = UIImage(data: data) else {
            message = "Gambar tidak bisa dibuka"
            return
        }
        if let raw = BarcodeReader.qrText(in: image) {
            handle(raw)
        } else {
            message = "QRIS tidak terbaca di gambar ini"
        }
    }
}

struct PasteCodeSheet: View {
    let onSubmit: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Kode QRIS atau nomor PIXPAY", text: $text, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle("Tempel kode")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Batal") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lanjut") {
                        onSubmit(text.trimmingCharacters(in: .whitespacesAndNewlines))
                        dismiss()
                    }
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

struct ScannerRepresentable: UIViewRepresentable {
    let onCode: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onCode: onCode)
    }

    func makeUIView(context: Context) -> CameraPreviewView {
        let view = CameraPreviewView()
        context.coordinator.start(on: view)
        return view
    }

    func updateUIView(_ uiView: CameraPreviewView, context: Context) {}

    static func dismantleUIView(_ uiView: CameraPreviewView, coordinator: Coordinator) {
        coordinator.stop()
    }

    final class CameraPreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }

        var previewLayer: AVCaptureVideoPreviewLayer {
            layer as! AVCaptureVideoPreviewLayer
        }
    }

    final class Coordinator: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        private let onCode: (String) -> Void
        private let session = AVCaptureSession()
        private var lastText = ""
        private var lastTime = Date.distantPast

        init(onCode: @escaping (String) -> Void) {
            self.onCode = onCode
        }

        func start(on view: CameraPreviewView) {
            view.previewLayer.session = session
            view.previewLayer.videoGravity = .resizeAspectFill
            guard let device = AVCaptureDevice.default(for: .video),
                  let input = try? AVCaptureDeviceInput(device: device),
                  session.canAddInput(input) else { return }
            session.addInput(input)

            let output = AVCaptureMetadataOutput()
            guard session.canAddOutput(output) else { return }
            session.addOutput(output)
            output.setMetadataObjectsDelegate(self, queue: .main)
            output.metadataObjectTypes = [.qr]

            let captureSession = session
            DispatchQueue.global(qos: .userInitiated).async {
                captureSession.startRunning()
            }
        }

        func stop() {
            let captureSession = session
            DispatchQueue.global(qos: .userInitiated).async {
                if captureSession.isRunning {
                    captureSession.stopRunning()
                }
            }
        }

        func metadataOutput(_ output: AVCaptureMetadataOutput,
                            didOutput metadataObjects: [AVMetadataObject],
                            from connection: AVCaptureConnection) {
            guard let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
                  let text = object.stringValue else { return }
            // Cegah pembacaan ganda untuk kode yang sama dalam waktu singkat.
            if text == lastText, Date().timeIntervalSince(lastTime) < 2 { return }
            lastText = text
            lastTime = Date()
            onCode(text)
        }
    }
}
