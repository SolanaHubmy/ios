import SwiftUI

struct PayView: View {
    let code: PayCode
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var amountText = ""
    @State private var note = ""
    @State private var showPin = false
    @State private var error: String?
    @State private var busy = false

    private var isPix: Bool { code.kind == .pixpay }
    private var blocked: Bool { !isPix && !store.cfg.qrisOut }
    private var amount: Double { code.fixed ? code.amount : (Double(amountText) ?? 0) }

    var body: some View {
        Form {
            Section {
                DetailRow(label: isPix ? "Penerima" : "Merchant", value: code.name)
                if !code.city.isEmpty {
                    DetailRow(label: "Kota", value: code.city)
                }
                DetailRow(label: "Saldo kamu", value: Money.rp(store.balance))
            }
            Section("Nominal") {
                if code.fixed {
                    DetailRow(label: "Nominal", value: Money.rp(code.amount))
                } else {
                    AmountField(label: "Nominal", text: $amountText)
                }
                TextField("Catatan (opsional)", text: $note)
            }
            if blocked {
                Section {
                    Text("Kode ini sudah terbaca, tetapi dana belum bisa dikirim ke merchant di aplikasi ini.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            if let error {
                Section {
                    Text(error).foregroundStyle(.red)
                }
            }
            Section {
                Button("Bayar sekarang") { validate() }
                    .disabled(blocked || busy)
                    .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle(isPix ? "Kirim ke PIXPAY" : "Bayar QRIS")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Batal") { dismiss() }
            }
        }
        .sheet(isPresented: $showPin) {
            PinSheet(title: "Konfirmasi PIN") { pin in
                showPin = false
                submit(pin: pin)
            }
        }
    }

    private func validate() {
        error = nil
        if amount < 1000 {
            error = "Minimal bayar Rp1.000"
        } else if amount > store.balance {
            error = "Saldo tidak cukup"
        } else {
            showPin = true
        }
    }

    private func submit(pin: String) {
        busy = true
        let noteText = note.trimmingCharacters(in: .whitespaces)
        Task {
            do {
                if isPix {
                    _ = try await store.transfer(type: "Sesama PIXPAY", dest: code.toPhone, bank: "",
                                                 holder: "", amount: amount, note: noteText, pin: pin)
                } else {
                    _ = try await store.pay(qris: code.raw, amount: amount, note: noteText, pin: pin)
                }
                dismiss()
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}
