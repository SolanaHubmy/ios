import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showEdit = false
    @State private var showPin = false
    @State private var showNotes = false
    @State private var confirmLogout = false

    var body: some View {
        List {
            Section {
                HStack(spacing: 14) {
                    ZStack {
                        Circle().fill(Color.brand)
                        Text(initial)
                            .font(.title2.weight(.bold))
                            .foregroundStyle(.white)
                    }
                    .frame(width: 56, height: 56)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(store.user.name ?? "Pengguna")
                            .font(.headline)
                        Text(store.user.phone ?? "")
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 4)
            }
            Section {
                Button {
                    showNotes = true
                } label: {
                    Label(store.unread > 0 ? "Notifikasi (\(store.unread) baru)" : "Notifikasi", systemImage: "bell")
                }
                Button {
                    showEdit = true
                } label: {
                    Label("Edit profil", systemImage: "person.crop.circle")
                }
                Button {
                    showPin = true
                } label: {
                    Label("Ganti PIN", systemImage: "key")
                }
                NavigationLink {
                    HelpView()
                } label: {
                    Label("Bantuan & chat", systemImage: "questionmark.circle")
                }
            }
            Section {
                Button(role: .destructive) {
                    confirmLogout = true
                } label: {
                    Label("Keluar", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }
        }
        .navigationTitle("Saya")
        .sheet(isPresented: $showEdit) { EditProfileSheet() }
        .sheet(isPresented: $showPin) { ChangePinSheet() }
        .sheet(isPresented: $showNotes) { NotificationsSheet() }
        .confirmationDialog("Keluar dari akun ini?", isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Keluar", role: .destructive) { store.logout() }
            Button("Batal", role: .cancel) {}
        }
    }

    private var initial: String {
        let name = (store.user.name ?? "P").trimmingCharacters(in: .whitespaces)
        return String(name.prefix(1)).uppercased()
    }
}

struct EditProfileSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var phone = ""
    @State private var error: String?
    @State private var busy = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Nama lengkap", text: $name)
                    TextField("Nomor HP", text: $phone)
                        .keyboardType(.phonePad)
                }
                if let error {
                    Section {
                        Text(error).foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("Edit profil")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                name = store.user.name ?? ""
                phone = store.user.phone ?? ""
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Batal") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Simpan") { save() }
                        .disabled(busy)
                }
            }
        }
    }

    private func save() {
        error = nil
        let fullName = name.trimmingCharacters(in: .whitespaces)
        let digits = phone.filter(\.isNumber)
        if fullName.count < 2 {
            error = "Nama minimal 2 karakter"
            return
        }
        if digits.count < 10 {
            error = "Nomor HP tidak valid"
            return
        }
        busy = true
        Task {
            do {
                try await store.updateProfile(name: fullName, phone: digits)
                dismiss()
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}

struct ChangePinSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var oldPin = ""
    @State private var newPin = ""
    @State private var confirmPin = ""
    @State private var error: String?
    @State private var busy = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("PIN lama", text: $oldPin)
                        .keyboardType(.numberPad)
                    SecureField("PIN baru (6 angka)", text: $newPin)
                        .keyboardType(.numberPad)
                    SecureField("Ulangi PIN baru", text: $confirmPin)
                        .keyboardType(.numberPad)
                }
                if let error {
                    Section {
                        Text(error).foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("Ganti PIN")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Batal") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Simpan") { save() }
                        .disabled(busy)
                }
            }
        }
    }

    private func save() {
        error = nil
        guard oldPin.count == 6, newPin.count == 6, newPin.allSatisfy(\.isNumber) else {
            error = "PIN harus 6 angka"
            return
        }
        guard newPin == confirmPin else {
            error = "Konfirmasi PIN tidak sama"
            return
        }
        busy = true
        Task {
            do {
                try await store.changePin(old: oldPin, new: newPin)
                dismiss()
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}

struct NotificationsSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if store.notes.isEmpty {
                    Text("Belum ada notifikasi").foregroundStyle(.secondary)
                }
                ForEach(store.notes.prefix(50)) { note in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(note.t ?? "")
                            .font(.headline)
                        Text(note.b ?? "")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Text(Money.date(note.ts))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                }
            }
            .navigationTitle("Notifikasi")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Tutup") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Tandai dibaca") {
                        Task { await store.markNotesRead() }
                    }
                }
            }
        }
    }
}
