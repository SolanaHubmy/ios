import SwiftUI

struct HelpView: View {
    @State private var tab = 0

    var body: some View {
        VStack(spacing: 0) {
            Picker("Bagian", selection: $tab) {
                Text("Pertanyaan").tag(0)
                Text("Chat").tag(1)
                Text("Tiket").tag(2)
            }
            .pickerStyle(.segmented)
            .padding()

            switch tab {
            case 1:
                ChatView()
            case 2:
                TicketsView()
            default:
                FAQView()
            }
        }
        .navigationTitle("Bantuan")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct FAQView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        List {
            ForEach(items, id: \.question) { item in
                DisclosureGroup(item.question) {
                    Text(item.answer)
                        .font(.body)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .listStyle(.insetGrouped)
    }

    private var items: [(question: String, answer: String)] {
        let cfg = store.cfg
        return [
            (question: "Berapa lama isi saldo via QRIS?",
             answer: "Saldo bertambah otomatis begitu pembayaran terkonfirmasi, biasanya kurang dari satu menit."),
            (question: "Berapa biaya transfer, tarik tunai, dan isi saldo?",
             answer: "Sesama PIXPAY gratis. Transfer bank \(Money.rp(cfg.fee)), DANA \(Money.rp(cfg.fd)). Tarik tunai \(Money.rp(cfg.feeTarikKecil)) (sampai \(Money.rp(cfg.small))) atau \(Money.rp(cfg.feeTarik)), ditambah PPN \(Int(cfg.pajakPct))% atas biaya admin. Isi saldo via QRIS mengikuti tarif QRIS."),
            (question: "Apa arti status Diproses?",
             answer: "Diproses berarti transaksi sudah dicatat dan sedang menunggu konfirmasi sistem. Status akan berubah otomatis setelah selesai.")
        ]
    }
}

struct ChatView: View {
    @EnvironmentObject private var store: AppStore
    @State private var messages: [ChatMsg] = []
    @State private var draft = ""
    @State private var pendingText = ""
    @State private var pendingCid = ""
    @State private var sending = false
    @State private var error: String?

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        if messages.isEmpty {
                            Text("Mulai percakapan dengan tim layanan.")
                                .foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity)
                        }
                        ForEach(messages) { message in
                            bubble(message)
                                .id(message.id)
                        }
                    }
                    .padding()
                }
                .onChange(of: messages.count) { _ in
                    if let last = messages.last {
                        withAnimation {
                            proxy.scrollTo(last.id, anchor: .bottom)
                        }
                    }
                }
            }
            if let error {
                Text(error)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .padding(.horizontal)
            }
            HStack(spacing: 8) {
                TextField("Tulis pesan", text: $draft, axis: .vertical)
                    .lineLimit(1...4)
                    .textFieldStyle(.roundedBorder)
                Button {
                    send()
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.title3)
                }
                .disabled(sending || draft.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            .padding()
        }
        .task {
            while !Task.isCancelled {
                if let list = try? await store.fetchChat() {
                    messages = list
                }
                try? await Task.sleep(nanoseconds: 4_000_000_000)
            }
        }
    }

    private func bubble(_ message: ChatMsg) -> some View {
        let mine = message.from == "user"
        let label: String
        switch message.from {
        case "agent": label = "Tim layanan"
        case "bot": label = "Asisten PIXPAY"
        default: label = "Kamu"
        }
        return HStack {
            if mine { Spacer(minLength: 40) }
            VStack(alignment: mine ? .trailing : .leading, spacing: 4) {
                Text(label)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Text(message.text ?? "")
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .foregroundStyle(mine ? Color.white : Color.primary)
                    .background(mine ? Color.brand : Color.subtleFill,
                                in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            if !mine { Spacer(minLength: 40) }
        }
    }

    private func send() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !sending else { return }
        if text != pendingText || pendingCid.isEmpty {
            pendingText = text
            pendingCid = UUID().uuidString
        }
        let cid = pendingCid
        sending = true
        error = nil
        Task {
            do {
                let sent = try await store.sendChat(text: text, cid: cid)
                if !messages.contains(where: { $0.id == sent.id }) {
                    messages.append(sent)
                }
                draft = ""
                pendingText = ""
                pendingCid = ""
            } catch {
                self.error = error.localizedDescription
            }
            sending = false
        }
    }
}

struct TicketsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var tickets: [Ticket] = []
    @State private var category = AppConfig.categories.last ?? "Lainnya"
    @State private var orderId = ""
    @State private var message = ""
    @State private var error: String?
    @State private var sending = false

    var body: some View {
        List {
            Section("Buat tiket") {
                Picker("Kategori", selection: $category) {
                    ForEach(AppConfig.categories, id: \.self) { Text($0).tag($0) }
                }
                TextField("ID transaksi (opsional)", text: $orderId)
                TextField("Jelaskan kendala (min. 10 karakter)", text: $message, axis: .vertical)
                    .lineLimit(3...8)
                if let error {
                    Text(error).foregroundStyle(.red)
                }
                Button(sending ? "Mengirim…" : "Kirim tiket") { create() }
                    .disabled(sending)
            }
            Section("Tiket saya") {
                if tickets.isEmpty {
                    Text("Belum ada tiket").foregroundStyle(.secondary)
                }
                ForEach(tickets) { ticket in
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(ticket.c ?? "Tiket") • \(ticket.st == "open" ? "Dibuka" : "Ditutup")")
                            .font(.headline)
                        Text(ticket.m ?? "")
                            .font(.subheadline)
                        if let reply = ticket.r, !reply.isEmpty {
                            Text("Balasan: \(reply)")
                                .font(.footnote)
                                .foregroundStyle(Color.brand)
                        }
                        Text(Money.date(ticket.ts))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .task { await load() }
        .refreshable { await load() }
    }

    private func load() async {
        if let list = try? await store.fetchTickets() {
            tickets = list
        }
    }

    private func create() {
        error = nil
        let text = message.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count >= 10 else {
            error = "Jelaskan kendala minimal 10 karakter"
            return
        }
        sending = true
        Task {
            do {
                let ticket = try await store.createTicket(
                    category: category,
                    orderId: orderId.trimmingCharacters(in: .whitespaces),
                    message: text
                )
                tickets.insert(ticket, at: 0)
                message = ""
                orderId = ""
            } catch {
                self.error = error.localizedDescription
            }
            sending = false
        }
    }
}
