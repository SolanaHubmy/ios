import SwiftUI

struct TransferView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var type = "Sesama PIXPAY"
    @State private var dest = ""
    @State private var bank = AppConfig.banks[0]
    @State private var holder = ""
    @State private var amountText = ""
    @State private var note = ""
    @State private var showPin = false
    @State private var error: String?
    @State private var busy = false

    private var amount: Double { Double(amountText) ?? 0 }

    private var fee: Double {
        switch type {
        case "Sesama PIXPAY": return 0
        case "DANA": return store.cfg.fd
        default: return store.cfg.fee
        }
    }

    var body: some View {
        Form {
            Section {
                Picker("Tujuan", selection: $type) {
                    Text("Sesama PIXPAY").tag("Sesama PIXPAY")
                    Text("Bank").tag("Bank")
                    Text("DANA").tag("DANA")
                }
                .pickerStyle(.segmented)
            }
            Section("Penerima") {
                TextField(type == "Bank" ? "Nomor rekening" : "Nomor HP", text: $dest)
                    .keyboardType(.numberPad)
                    .onChange(of: dest) { value in
                        dest = String(value.filter(\.isNumber).prefix(16))
                    }
                if type == "Bank" {
                    Picker("Bank", selection: $bank) {
                        ForEach(AppConfig.banks, id: \.self) { Text($0).tag($0) }
                    }
                    TextField("Nama pemilik rekening", text: $holder)
                } else if type == "DANA" {
                    TextField("Nama penerima (opsional)", text: $holder)
                }
            }
            Section("Nominal") {
                AmountField(label: "Nominal", text: $amountText)
                QuickAmounts(values: [10_000, 50_000, 100_000, 250_000]) { value in
                    amountText = String(Int(value))
                }
                TextField("Catatan (opsional)", text: $note)
            }
            Section("Ringkasan") {
                DetailRow(label: "Biaya", value: Money.rp(fee))
                DetailRow(label: "Total", value: Money.rp(amount + fee))
                DetailRow(label: "Saldo kamu", value: Money.rp(store.balance))
            }
            if let error {
                Section {
                    Text(error).foregroundStyle(.red)
                }
            }
            Section {
                Button("Lanjut") { validate() }
                    .disabled(busy)
                    .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("Kirim uang")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showPin) {
            PinSheet(title: "Konfirmasi PIN") { pin in
                showPin = false
                submit(pin: pin)
            }
        }
    }

    private func validate() {
        error = nil
        let holderName = holder.trimmingCharacters(in: .whitespaces)
        if type == "Bank" && !(8...16).contains(dest.count) {
            error = "Nomor rekening harus 8–16 digit"
        } else if type != "Bank" && dest.count < 10 {
            error = "Nomor HP tidak valid"
        } else if type == "Bank" && holderName.count < 2 {
            error = "Isi nama pemilik rekening"
        } else if amount < AppConfig.minTransfer {
            error = "Minimal kirim Rp1.000"
        } else if amount > AppConfig.maxTransfer {
            error = "Maksimal Rp25.000.000 per transaksi"
        } else if amount + fee > store.balance {
            error = "Saldo tidak cukup (termasuk biaya)"
        } else {
            showPin = true
        }
    }

    private func submit(pin: String) {
        busy = true
        Task {
            do {
                _ = try await store.transfer(
                    type: type,
                    dest: dest,
                    bank: type == "Bank" ? bank : "",
                    holder: holder.trimmingCharacters(in: .whitespaces),
                    amount: amount,
                    note: note.trimmingCharacters(in: .whitespaces),
                    pin: pin
                )
                dismiss()
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}

struct WithdrawView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var bank = AppConfig.banks[0]
    @State private var account = ""
    @State private var holder = ""
    @State private var amountText = ""
    @State private var showPin = false
    @State private var error: String?
    @State private var busy = false

    private var amount: Double { Double(amountText) ?? 0 }
    private var admin: Double { Money.tarikAdmin(amount: amount, cfg: store.cfg) }
    private var tax: Double { Money.pajak(admin: admin, cfg: store.cfg) }

    var body: some View {
        Form {
            Section("Rekening tujuan") {
                Picker("Bank", selection: $bank) {
                    ForEach(AppConfig.banks, id: \.self) { Text($0).tag($0) }
                }
                TextField("Nomor rekening", text: $account)
                    .keyboardType(.numberPad)
                    .onChange(of: account) { value in
                        account = String(value.filter(\.isNumber).prefix(16))
                    }
                TextField("Nama pemilik rekening", text: $holder)
            }
            Section("Nominal") {
                AmountField(label: "Nominal", text: $amountText)
                QuickAmounts(values: [50_000, 100_000, 250_000, 500_000]) { value in
                    amountText = String(Int(value))
                }
            }
            Section("Rincian biaya") {
                DetailRow(label: "Biaya admin", value: Money.rp(admin))
                DetailRow(label: "PPN \(Int(store.cfg.pajakPct))%", value: Money.rp(tax))
                DetailRow(label: "Total potong saldo", value: Money.rp(amount + admin + tax))
                DetailRow(label: "Saldo kamu", value: Money.rp(store.balance))
            }
            if let error {
                Section {
                    Text(error).foregroundStyle(.red)
                }
            }
            Section {
                Button("Lanjut") { validate() }
                    .disabled(busy)
                    .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("Tarik tunai")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showPin) {
            PinSheet(title: "Konfirmasi PIN") { pin in
                showPin = false
                submit(pin: pin)
            }
        }
    }

    private func validate() {
        error = nil
        let holderName = holder.trimmingCharacters(in: .whitespaces)
        if amount < AppConfig.minWithdraw {
            error = "Minimal tarik Rp10.000"
        } else if !(8...16).contains(account.count) {
            error = "Nomor rekening harus 8–16 digit"
        } else if holderName.count < 2 {
            error = "Isi nama pemilik rekening"
        } else if amount + admin + tax > store.balance {
            error = "Saldo tidak cukup (termasuk biaya)"
        } else {
            showPin = true
        }
    }

    private func submit(pin: String) {
        busy = true
        Task {
            do {
                _ = try await store.withdraw(
                    amount: amount,
                    bank: bank,
                    no: account,
                    holder: holder.trimmingCharacters(in: .whitespaces),
                    pin: pin
                )
                dismiss()
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}
