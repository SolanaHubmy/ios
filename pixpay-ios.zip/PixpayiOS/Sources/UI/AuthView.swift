import SwiftUI

struct AuthView: View {
    @EnvironmentObject private var store: AppStore
    @State private var isRegister = false
    @State private var name = ""
    @State private var phone = ""
    @State private var pin = ""
    @State private var error: String?
    @State private var busy = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Mode", selection: $isRegister) {
                        Text("Masuk").tag(false)
                        Text("Daftar").tag(true)
                    }
                    .pickerStyle(.segmented)
                }
                Section {
                    if isRegister {
                        TextField("Nama lengkap", text: $name)
                            .textContentType(.name)
                    }
                    TextField("Nomor HP (08…)", text: $phone)
                        .keyboardType(.phonePad)
                        .textContentType(.telephoneNumber)
                    SecureField("PIN (6 angka)", text: $pin)
                        .keyboardType(.numberPad)
                } footer: {
                    Text("PIXPAY tidak pernah meminta PIN lewat chat atau telepon.")
                }
                if let error {
                    Section {
                        Text(error).foregroundStyle(.red)
                    }
                }
                Section {
                    Button(action: submit) {
                        HStack {
                            Spacer()
                            if busy {
                                ProgressView()
                            } else {
                                Text(isRegister ? "Daftar" : "Masuk").fontWeight(.semibold)
                            }
                            Spacer()
                        }
                    }
                    .disabled(busy)
                }
            }
            .navigationTitle("PIXPAY")
        }
    }

    private func submit() {
        error = nil
        let digits = phone.filter(\.isNumber)
        let fullName = name.trimmingCharacters(in: .whitespaces)
        if isRegister && fullName.count < 2 {
            error = "Nama minimal 2 karakter"
            return
        }
        guard digits.count >= 10, digits.count <= 13, digits.hasPrefix("0") else {
            error = "Nomor HP tidak valid, contoh 081234567890"
            return
        }
        guard pin.count == 6, pin.allSatisfy(\.isNumber) else {
            error = "PIN harus 6 angka"
            return
        }
        busy = true
        Task {
            do {
                if isRegister {
                    try await store.register(name: fullName, phone: digits, pin: pin)
                } else {
                    try await store.login(phone: digits, pin: pin)
                }
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}
