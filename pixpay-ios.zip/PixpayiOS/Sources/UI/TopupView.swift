import SwiftUI
import UIKit

struct TopupView: View {
    @EnvironmentObject private var store: AppStore
    @State private var method = "QRIS"
    @State private var bank = AppConfig.vaBanks[0]
    @State private var amountText = ""
    @State private var created: Tx?
    @State private var error: String?
    @State private var busy = false

    private var amount: Double { Double(amountText) ?? 0 }

    private var live: Tx? {
        if let id = created?.id, let fresh = store.transactions.first(where: { $0.id == id }) {
            return fresh
        }
        return created
    }

    var body: some View {
        Form {
            if let current = live {
                resultSections(current)
            } else {
                inputSections
            }
        }
        .navigationTitle("Isi saldo")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: created?.id) {
            guard let id = created?.id else { return }
            while !Task.isCancelled {
                if let current = store.transactions.first(where: { $0.id == id }), current.status != "pending" {
                    return
                }
                await store.refresh()
                try? await Task.sleep(nanoseconds: 4_000_000_000)
            }
        }
    }

    @ViewBuilder
    private var inputSections: some View {
        Section {
            Picker("Metode", selection: $method) {
                Text("QRIS").tag("QRIS")
                if store.cfg.vaAktif == 1 {
                    Text("Transfer VA").tag("VA")
                }
            }
            .pickerStyle(.segmented)
        }
        Section("Nominal") {
            if method == "VA" {
                Picker("Bank", selection: $bank) {
                    ForEach(AppConfig.vaBanks, id: \.self) { Text($0).tag($0) }
                }
            }
            AmountField(label: "Nominal", text: $amountText)
            QuickAmounts(values: [50_000, 100_000, 250_000, 500_000]) { value in
                amountText = String(Int(value))
            }
        }
        Section("Biaya") {
            if method == "VA" {
                DetailRow(label: "Biaya admin", value: Money.rp(store.cfg.feeIsi))
                DetailRow(label: "PPN \(Int(store.cfg.pajakPct))%",
                          value: Money.rp(Money.pajak(admin: store.cfg.feeIsi, cfg: store.cfg)))
            } else {
                Text("Biaya QRIS mengikuti tarif QRIS dan ditampilkan saat kode dibuat.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        if let error {
            Section {
                Text(error).foregroundStyle(.red)
            }
        }
        Section {
            Button(busy ? "Memproses…" : "Buat kode pembayaran") { create() }
                .disabled(busy)
                .frame(maxWidth: .infinity)
        }
    }

    @ViewBuilder
    private func resultSections(_ tx: Tx) -> some View {
        Section {
            switch tx.status {
            case "ok":
                Label("Isi saldo berhasil", systemImage: "checkmark.seal.fill")
                    .foregroundStyle(Color.okGreen)
            case "fail":
                Label("Pembayaran gagal atau kedaluwarsa", systemImage: "xmark.octagon.fill")
                    .foregroundStyle(.red)
            default:
                HStack {
                    ProgressView()
                    Text("Menunggu pembayaran…")
                }
            }
            DetailRow(label: "Nominal", value: Money.rp(tx.amount))
            DetailRow(label: "Total bayar", value: Money.rp(tx.total ?? 0))
        }
        if let va = tx.va, !va.isEmpty {
            Section("Nomor Virtual Account") {
                Text(va)
                    .font(.title3.monospacedDigit())
                    .textSelection(.enabled)
                Button("Salin nomor") {
                    UIPasteboard.general.string = va
                }
            }
        }
        if tx.status == "pending", let qr = tx.qr, !qr.isEmpty {
            Section("Kode QRIS") {
                QRImageView(source: qr)
                    .frame(maxWidth: .infinity)
                    .frame(height: 260)
            }
        }
        Section {
            Button(tx.status == "pending" ? "Tutup" : "Selesai") {
                created = nil
                amountText = ""
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func create() {
        error = nil
        guard amount >= AppConfig.minTopup, amount <= AppConfig.maxTopup else {
            error = "Isi saldo antara Rp10.000 dan Rp2.000.000"
            return
        }
        busy = true
        let methodValue = method == "VA" ? bank : "QRIS"
        Task {
            do {
                created = try await store.topup(method: methodValue, amount: amount)
            } catch {
                self.error = error.localizedDescription
            }
            busy = false
        }
    }
}
