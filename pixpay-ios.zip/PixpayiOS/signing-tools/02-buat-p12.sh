#!/usr/bin/env bash
# Mengubah sertifikat dari Apple (.cer) dan private key menjadi file .p12 untuk Codemagic.
# Pakai: ./02-buat-p12.sh distribution.cer   (ios_dist.key dari langkah 01 harus ada di folder ini)
set -euo pipefail
CER="${1:-}"
if [ -z "$CER" ] || [ ! -f "$CER" ] || [ ! -f ios_dist.key ]; then
  echo "Pakai: ./02-buat-p12.sh distribution.cer"
  echo "Pastikan ios_dist.key dari langkah 01 ada di folder ini."
  exit 1
fi
if ! openssl x509 -inform DER -in "$CER" -out ios_dist.pem 2>/dev/null; then
  openssl x509 -in "$CER" -out ios_dist.pem
fi
CERT_MOD="$(openssl x509 -noout -modulus -in ios_dist.pem | openssl md5)"
KEY_MOD="$(openssl rsa -noout -modulus -in ios_dist.key | openssl md5)"
if [ "$CERT_MOD" != "$KEY_MOD" ]; then
  echo "GAGAL: sertifikat ini bukan pasangan dari ios_dist.key."
  echo "Pastikan sertifikat diunduh dari CSR yang dibuat di langkah 01."
  exit 1
fi
PASS="$(openssl rand -hex 12)"
openssl pkcs12 -export -inkey ios_dist.key -in ios_dist.pem -out ios_dist.p12 -passout "pass:${PASS}"
echo "Selesai: ios_dist.p12"
echo "Password .p12 (dipakai saat upload ke Codemagic): ${PASS}"
