#!/usr/bin/env bash
# Memeriksa file .mobileprovision sebelum diunggah ke Codemagic.
# Pakai: ./03-cek-profil.sh NAMA.mobileprovision [ios_dist.pem]
set -euo pipefail
PROFILE="${1:-}"
CERT_PEM="${2:-ios_dist.pem}"
if [ -z "$PROFILE" ] || [ ! -f "$PROFILE" ]; then
  echo "Pakai: ./03-cek-profil.sh NAMA.mobileprovision [ios_dist.pem]"
  exit 1
fi
PLIST="$(mktemp)"
trap 'rm -f "$PLIST"' EXIT
if ! openssl smime -verify -noverify -inform DER -in "$PROFILE" -out "$PLIST" >/dev/null 2>&1; then
  echo "GAGAL: file ini tidak bisa dibaca. Pastikan ini file .mobileprovision asli dari Apple."
  exit 1
fi
python3 - "$PLIST" "$CERT_PEM" <<'PY'
import datetime, os, plistlib, ssl, sys

plist_path, cert_path = sys.argv[1], sys.argv[2]
BUNDLE = "com.pixpay.app"
ok = True

def warn(msg):
    global ok
    ok = False
    print("PERINGATAN:", msg)

with open(plist_path, "rb") as f:
    prof = plistlib.load(f)

ent = prof.get("Entitlements", {})
app_id = ent.get("application-identifier", "")
bundle = app_id.split(".", 1)[1] if "." in app_id else ""
print("Nama profil :", prof.get("Name"))
print("App ID      :", app_id)
if bundle == BUNDLE:
    print("Bundle ID   : OK")
else:
    warn(f"Bundle ID profil '{bundle}' seharusnya '{BUNDLE}'.")

if "ProvisionedDevices" in prof or prof.get("ProvisionsAllDevices"):
    warn("Profil ini untuk Development atau Ad Hoc. Buat ulang dengan tipe App Store Connect.")
if ent.get("get-task-allow"):
    warn("get-task-allow bernilai true, berarti profil development.")

exp = prof.get("ExpirationDate")
if isinstance(exp, datetime.datetime):
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=datetime.timezone.utc)
    if exp < datetime.datetime.now(datetime.timezone.utc):
        warn(f"Profil sudah kedaluwarsa pada {exp}.")
    else:
        print("Berlaku s/d :", exp)

certs = prof.get("DeveloperCertificates", [])
print("Sertifikat di profil:", len(certs))
if os.path.isfile(cert_path):
    with open(cert_path) as cf:
        der = ssl.PEM_cert_to_DER_cert(cf.read())
    if der in certs:
        print("Sertifikat  : cocok dengan", cert_path)
    else:
        warn(f"Sertifikat di {cert_path} tidak ada di profil ini. Pastikan profil dibuat dari sertifikat yang sama.")
else:
    warn(f"File sertifikat {cert_path} tidak ditemukan, cek sertifikat dilewati.")

print("HASIL:", "SIAP DIUNGGAH KE CODEMAGIC" if ok else "ADA MASALAH, PERBAIKI DULU")
sys.exit(0 if ok else 1)
PY
