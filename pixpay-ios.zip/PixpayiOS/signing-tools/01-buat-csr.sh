#!/usr/bin/env bash
# Membuat private key dan CSR untuk sertifikat Apple Distribution.
# Pakai: ./01-buat-csr.sh email@kamu.com
set -euo pipefail
EMAIL="${1:-}"
if [ -z "$EMAIL" ]; then
  echo "Pakai: ./01-buat-csr.sh email@kamu.com"
  exit 1
fi
if [ -f ios_dist.key ]; then
  echo "ios_dist.key sudah ada. Hapus atau pindahkan dulu jika ingin membuat ulang."
  exit 1
fi
openssl req -new -newkey rsa:2048 -nodes \
  -keyout ios_dist.key -out ios_dist.csr \
  -subj "/emailAddress=${EMAIL}/CN=PIXPAY Distribution/C=ID"
chmod 600 ios_dist.key
echo "Selesai."
echo "- ios_dist.csr : unggah ke developer.apple.com (Certificates → +)"
echo "- ios_dist.key : simpan baik-baik, jangan dibagikan"
