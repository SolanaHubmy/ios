# Perbaiki error signing Codemagic

Error yang muncul:

> No matching profiles found for bundle identifier "com.pixpay.app" and distribution type "app_store"

Artinya Codemagic tidak menemukan sertifikat distribusi dan profil App Store untuk `com.pixpay.app`, dan gagal membuatnya otomatis. Error ini terjadi sebelum kode proyek dijalankan, jadi bukan karena kode Swift.

Penyebab yang paling sering:
1. Membership Apple Developer Program belum aktif. Akun gratis tidak bisa membuat profil App Store.
2. API key di Codemagic bukan role Admin, atau nama integrasi di `codemagic.yaml` tidak sama dengan nama di Codemagic.
3. App ID `com.pixpay.app` belum terdaftar, atau sertifikat distribusi sudah mencapai batas.

Langkah di bawah harus dijalankan di akun Apple dan Codemagic milikmu sendiri.

## Sebelum mulai
- [ ] Membership aktif: developer.apple.com → Account → Membership details. Statusnya harus Active.
- [ ] Ikon 1024×1024 PNG sudah ada di `Resources/Assets.xcassets/AppIcon.appiconset`. Ini wajib untuk upload TestFlight.

## Cara A: otomatis oleh Codemagic (tanpa terminal)

1. **Buat App ID.** developer.apple.com → Certificates, Identifiers & Profiles → Identifiers → + → App IDs → App. Description: `PIXPAY`. Bundle ID: pilih Explicit, isi `com.pixpay.app`. Klik Continue lalu Register. Lewati langkah ini jika sudah ada.
2. **Buat API key dengan role Admin.** App Store Connect → Users and Access → Integrations → App Store Connect API → Team Keys → +. Pilih Access **Admin**, lalu Generate. Catat Issuer ID dan Key ID. Unduh `AuthKey_XXXX.p8`. File ini hanya bisa diunduh sekali.
3. **Perbarui integrasi di Codemagic.** Teams → Integrations → App Store Connect. Isi Issuer ID, Key ID, dan upload file `.p8` dari langkah 2. Beri nama, misalnya `pixpay-asc`.
4. **Samakan nama di `codemagic.yaml`.** Ganti `NAMA_INTEGRASI_APP_STORE_CONNECT` dengan nama dari langkah 3. Huruf besar dan kecil harus sama persis.
5. **Cek batas sertifikat.** developer.apple.com → Certificates → filter Apple Distribution. Jika sudah ada 2 sertifikat aktif, cabut (Revoke) yang tidak dipakai aplikasi lain.
6. Start new build.

Jika build sudah lewat tahap signing, masalahnya sudah beres. Jika error yang sama masih muncul, lanjut ke Cara B.

## Cara B: manual (jika Cara A masih gagal)

Cara ini butuh terminal: VPS Linux, atau Git Bash di Windows. Skripnya ada di folder `signing-tools`.

1. Buat kunci dan CSR: `./01-buat-csr.sh email@kamu.com`. Hasilnya `ios_dist.csr` dan `ios_dist.key`.
2. developer.apple.com → Certificates → + → pilih **Apple Distribution**. Unggah `ios_dist.csr`, lalu unduh `distribution.cer`.
3. Ubah menjadi `.p12`: `./02-buat-p12.sh distribution.cer`. Catat password yang ditampilkan.
4. Buat App ID `com.pixpay.app` seperti Cara A langkah 1.
5. developer.apple.com → Profiles → + → pilih **App Store Connect**. Pilih App ID `com.pixpay.app`, pilih sertifikat Apple Distribution tadi, beri nama `PIXPAY AppStore`, lalu unduh `.mobileprovision`.
6. Periksa profil: `./03-cek-profil.sh PIXPAY_AppStore.mobileprovision ios_dist.pem`. Hasilnya harus `SIAP DIUNGGAH KE CODEMAGIC`. Jika ada PERINGATAN, perbaiki dulu.
7. Di Codemagic → Teams → Code signing identities:
   - **iOS certificates** → Add: unggah `ios_dist.p12`, lalu masukkan password dari langkah 3.
   - **Provisioning profiles** → Add: unggah `PIXPAY_AppStore.mobileprovision`.
8. Start new build.

Integrasi App Store Connect tetap diperlukan untuk upload TestFlight (Cara A langkah 2–4). Tapi signing di Cara B tidak bergantung pada integrasi itu.

## Jangan dilakukan
- Jangan membagikan atau mengunggah ke GitHub: `.p8`, `.key`, `.p12`, password, atau `.mobileprovision`. Simpan hanya di Codemagic dan di tempat penyimpanan pribadimu.
- Jangan membuat sertifikat berulang-ulang. Batasnya cepat penuh.

## Jika error berikutnya muncul

| Pesan | Tindakan |
|---|---|
| No matching profiles (setelah Cara A) | Cek role Admin, nama integrasi di yaml, dan App ID. Lanjut ke Cara B. |
| Pesan tentang batas sertifikat (maximum certificates) | Cabut sertifikat Apple Distribution lama yang tidak dipakai, lalu ulangi. |
| Pesan tentang API key atau not authorized | Buat ulang API key role Admin dan perbarui integrasi di Codemagic. |
| Signing lolos, gagal di Generate proyek Xcode atau Build IPA | Itu bukan masalah signing. Kirim screenshot langkah yang merah. |
