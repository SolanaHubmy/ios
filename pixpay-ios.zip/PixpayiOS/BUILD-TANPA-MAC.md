# Build IPA tanpa Mac

Build IPA hanya bisa dilakukan di macOS. Karena tidak punya Mac, build dijalankan di mesin macOS milik GitHub (GitHub Actions). Kamu cukup memakai browser. Akun Apple Developer tetap diperlukan untuk menandatangani IPA.

## Yang perlu disiapkan
1. Akun Apple Developer Program (berbayar, sekitar US$99 per tahun). Tanpa ini, IPA tidak bisa dipasang lewat TestFlight.
2. Akun GitHub gratis.
3. Ikon aplikasi PNG 1024×1024 tanpa transparansi (wajib untuk upload ke App Store Connect).
4. Komputer apa pun untuk mengolah sertifikat: VPS Linux, Windows (PowerShell atau Git Bash), atau HP dengan terminal. Mac tidak diperlukan.

## 1. Bundle ID dan app record
- developer.apple.com → Certificates, Identifiers & Profiles → Identifiers → + → App IDs → App. Bundle ID: `com.pixpay.app`.
- App Store Connect → Apps → + → New App. Platform iOS, Name `PIXPAY`, Bundle ID `com.pixpay.app`, SKU `pixpay-ios`.

## 2. Sertifikat distribusi (tanpa Mac)
Buat private key dan CSR:
```
openssl req -new -newkey rsa:2048 -nodes -keyout ios_dist.key -out ios_dist.csr -subj "/CN=PIXPAY/C=ID"
```
- developer.apple.com → Certificates → + → Apple Distribution → unggah `ios_dist.csr` → unduh `ios_dist.cer`.
- Ubah menjadi `.p12`:
```
openssl x509 -inform DER -in ios_dist.cer -out ios_dist.pem
openssl pkcs12 -export -inkey ios_dist.key -in ios_dist.pem -out ios_dist.p12 -password pass:PASSWORD_KAMU
```

## 3. Provisioning profile
- developer.apple.com → Profiles → + → App Store Connect (Distribution).
- Pilih App ID `com.pixpay.app`, lalu sertifikat Apple Distribution tadi.
- Beri nama profil, misalnya `PIXPAY AppStore`, lalu unduh file `.mobileprovision`.

## 4. Kunci API App Store Connect (untuk upload TestFlight)
- App Store Connect → Users and Access → Integrations → App Store Connect API → Generate API Key. Role: App Manager.
- Catat Key ID dan Issuer ID. File `AuthKey_XXXX.p8` hanya bisa diunduh sekali, jadi simpan baik-baik.

## 5. Ubah isi ke base64
Hasilnya dipakai sebagai secret. Lakukan untuk `ios_dist.p12`, file `.mobileprovision`, dan `AuthKey_XXXX.p8`.
- Linux / Git Bash: `base64 -w0 ios_dist.p12 > ios_dist.p12.b64`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("ios_dist.p12")) | Out-File -NoNewline ios_dist.p12.b64`

## 6. Repository GitHub
- Buat repository PRIVATE bernama `pixpay-ios`.
- Unggah isi folder `PixpayiOS` ke root repository, termasuk folder `.github`. Cara termudah: GitHub Desktop (Windows) lalu Publish. Dari iPhone, unggah folder lewat web tidak praktis.
- Ganti domain di `Sources/App/AppConfig.swift`.
- Tambahkan ikon: simpan `AppIcon.png` (1024×1024) di `Resources/Assets.xcassets/AppIcon.appiconset`, lalu ubah `Contents.json` menjadi:
```json
{
  "images" : [
    { "filename" : "AppIcon.png", "idiom" : "universal", "platform" : "ios", "size" : "1024x1024" }
  ],
  "info" : { "author" : "xcode", "version" : 1 }
}
```

## 7. Secrets
Repository → Settings → Secrets and variables → Actions → New repository secret:

| Nama secret | Isi |
|---|---|
| `APPLE_TEAM_ID` | Team ID 10 karakter (developer.apple.com → Membership details) |
| `IOS_DIST_P12_BASE64` | isi `ios_dist.p12.b64` |
| `IOS_DIST_P12_PASSWORD` | password saat membuat `.p12` |
| `IOS_PROFILE_BASE64` | base64 dari file `.mobileprovision` |
| `ASC_KEY_ID` | Key ID App Store Connect |
| `ASC_ISSUER_ID` | Issuer ID App Store Connect |
| `ASC_KEY_P8_BASE64` | base64 dari `AuthKey_XXXX.p8` |

Tiga secret terakhir opsional. Jika dikosongkan, IPA tetap dibuat dan bisa diunduh dari artifact, tetapi tidak otomatis dikirim ke TestFlight.

## 8. Jalankan build
- Tab Actions → Build IPA (iOS) → Run workflow.
- Tunggu sekitar 10–20 menit.
- IPA ada di halaman run → Artifacts → `PIXPAY-ipa-N`.
- Jika secret App Store Connect diisi, IPA otomatis dikirim ke App Store Connect. Setelah status Processing selesai, buka TestFlight → tambahkan dirimu sebagai internal tester → pasang aplikasi TestFlight di iPhone → pasang PIXPAY.

## Kuota dan biaya
- GitHub Free untuk repository private memberi 2.000 menit per bulan. Runner macOS dihitung 10 kali lipat, sehingga sekitar 200 menit macOS per bulan. Cukup untuk beberapa kali build.
- Apple Developer Program dibayar per tahun.

## Jika build gagal
Buka tab Actions, pilih run yang gagal, lalu salin baris error dan kirim ke saya. Penyebab yang paling umum:
- `No signing certificate`: isi `.p12` atau password salah.
- `No profiles`: profil bukan untuk `com.pixpay.app`, atau tidak cocok dengan sertifikat.
- `Missing 1024x1024 icon`: ikon belum ditambahkan (langkah 6).
- Perjanjian Apple belum diterima: masuk ke developer.apple.com dan App Store Connect, lalu terima perjanjiannya.
