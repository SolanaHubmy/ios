# PIXPAY — aplikasi iOS (SwiftUI)

Aplikasi iPhone dan iPad native. Seluruh UI memakai SwiftUI. Tidak ada WKWebView dan tidak ada wrapper website.

## Status (jujur)
- Source code Swift sudah lengkap untuk fitur utama (lihat daftar di bawah).
- **Belum dikompilasi.** Proyek ini dibuat di lingkungan tanpa macOS dan Xcode, jadi tidak ada hasil build, file .app, atau .ipa yang diklaim. Saat pertama kali dibuka di Xcode, mungkin ada error kecil. Kirim pesan error-nya untuk diperbaiki.
- File `.xcodeproj` tidak disertakan karena harus dibuat di macOS. Gunakan XcodeGen; `project.yml` sudah disiapkan.

## Syarat
- Mac dengan macOS 14 atau lebih baru dan Xcode 15.4 atau lebih baru (Swift 5.9)
- Target minimum: iOS 16.0 (iPhone dan iPad)
- Akun Apple Developer: gratis untuk menjalankan di iPhone sendiri; berbayar untuk TestFlight atau App Store

## Langkah
1. Pasang XcodeGen: `brew install xcodegen`
2. Di folder `PixpayiOS`, jalankan `xcodegen generate`. Perintah ini membuat `PIXPAY.xcodeproj`.
3. Ganti `apiBase` di `Sources/App/AppConfig.swift` dengan domain HTTPS server kamu.
4. Buka `PIXPAY.xcodeproj`, pilih target PIXPAY, lalu di Signing & Capabilities pilih Team.
5. Pilih iPhone atau iPad (atau simulator), lalu tekan Run (⌘R).

## Verifikasi kompilasi dari terminal
```
xcodebuild -project PIXPAY.xcodeproj -scheme PIXPAY \
  -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```
Perintah ini hanya memeriksa kompilasi. Hasilnya belum bisa dipasang di perangkat.

## Build .ipa yang ditandatangani
1. Pilih destination "Any iOS Device (arm64)".
2. Product → Archive.
3. Di Organizer, pilih Distribute App, lalu pilih metode (Development, Ad Hoc, atau App Store Connect). Xcode mengurus sertifikat dan provisioning profile.
4. Untuk ekspor dari terminal, buat `ExportOptions.plist` dari Xcode lalu jalankan:
   `xcodebuild -exportArchive -archivePath PIXPAY.xcarchive -exportOptionsPlist ExportOptions.plist -exportPath out`

## Yang perlu kamu lengkapi
- Ikon aplikasi 1024×1024 di `Resources/Assets.xcassets/AppIcon.appiconset` (wajib untuk App Store).
- Ganti `apiBase` dengan domain HTTPS server.
- Server memakai `server.js` yang sama dengan versi web, dan harus berjalan di HTTPS.

## Permission
- Kamera: hanya saat membuka Bayar QRIS (`NSCameraUsageDescription`).
- Import gambar memakai PhotosPicker, jadi tidak meminta izin foto.
- Tidak meminta lokasi, kontak, notifikasi, atau izin lain.

## Penyimpanan
- Token sesi disimpan di Keychain dengan `AfterFirstUnlockThisDeviceOnly`.
- PIN tidak pernah disimpan di perangkat.

## Catatan teknis
- Isi saldo Transfer VA mengirim nama bank sebagai `method`, sesuai pemakaian di versi web. Jika server menolak nilai ini, ubah di `AppStore.topup`.
- Terima menampilkan QR berisi `PIXPAY:<nomor HP>`.
- Chat memakai polling setiap 4 detik, dan berhenti otomatis saat layar ditutup.

## Fitur
Selesai (sudah ditulis, belum diuji di perangkat):
- Masuk dan daftar dengan nomor HP dan PIN 6 digit, serta keluar.
- Beranda: saldo (bisa disembunyikan), ringkasan bulan ini, transaksi terbaru, pengumuman, status pemeliharaan, dan menu cepat.
- Riwayat: filter Semua, Masuk, dan Keluar, serta detail transaksi.
- Kirim: Sesama PIXPAY, Bank, dan DANA, dengan biaya dan konfirmasi PIN.
- Tarik tunai: bank, rekening, nama pemilik, biaya bertingkat ditambah PPN, dan PIN.
- Isi saldo: QRIS (kode dari server, status dipantau) dan Transfer VA.
- Terima: QR PIXPAY dan salin nomor.
- Bayar QRIS: kamera (AVFoundation), import gambar (Vision), tempel kode, validasi CRC, pembayaran ke sesama PIXPAY, dan merchant mengikuti status `qris_out` dari server.
- Laporan: ringkasan per bulan dan pengeluaran per kategori.
- Saya: notifikasi, edit profil, ganti PIN, dan keluar.
- Bantuan: FAQ, chat dengan tim layanan, dan tiket.
- Tagihan: tampil terkunci dengan label "Coming soon", sama seperti versi web.

Belum:
- Panel admin (tetap dikelola lewat web admin).
- Realtime (saat ini polling).
- Unduh struk sebagai gambar atau PDF.
- Kunci Face ID dan push notification.
- Pembayaran tagihan (PLN, pulsa, dll.), karena belum ada di server.
- Pengujian di perangkat dan simulator.
